# Smoke & Vape Detection System

This project detects smoke or vape particles in washrooms and alerts teachers automatically.

## Contents
- 3D_Model: STL enclosure
- Images: Render preview (to add)
- Firmware: Code space